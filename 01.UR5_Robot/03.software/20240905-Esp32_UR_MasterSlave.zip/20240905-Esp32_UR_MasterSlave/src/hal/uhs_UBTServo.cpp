#include "uhs_UBTServo.h"

HardwareSerial *pServoSerial = nullptr;
void serial_UBT_Init(HardwareSerial *serial)
{
  pServoSerial = serial;
}
uint8_t command3[10] = {0xFA, 0xAF, 0x01, 0x01, 0xD2, 0x00, 0x00, 0x00, 0xD4, 0xED};//210
void ubtServo_Moveto(uint8_t id, uint8_t pos)
{
    uint8_t cmd[10] = {0};
    // 装载命令
    cmd[0] = 0xFA;                                                // 帧头
    cmd[1] = 0xAF;                                                // 帧头
    cmd[2] = id;                                                  // 舵机id
    cmd[3] = 0x01;                                                // 命令码 01运行到位置
    cmd[4] = pos;                                                 // 目标角度 0-240
    cmd[5] = 0;                                                   // 运动时间0-255/20ms
    cmd[6] = 0;                                                   // 高八位
    cmd[7] = 0;                                                   // 低八位 uint16,锁定时间0-3270/20mm
    cmd[8] = cmd[2] + cmd[3] + cmd[4] + cmd[5] + cmd[6] + cmd[7]; // 校验位
    cmd[9] = 0xED;                                                // 帧尾
    // 发送命令
    // Serial.printf("舵机 %d  位置 %d  ||  ",id,pos);
    pServoSerial->write(cmd, 10);
}
