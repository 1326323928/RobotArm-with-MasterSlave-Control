#ifndef _SERIALREC_H_
#define _SERIALREC_H_

#include "uhs_config.h"
#include "uhs_kine_3axis.h"
extern SemaphoreHandle_t xSerialMutex;
extern HardwareSerial *pRecSerial;

void serial_Rec_Init(HardwareSerial *serial);











#endif