#ifndef _UHS_BLE_H_
#define _UHS_BLE_H_

#include <BLEDevice.h>
#include <BLE2902.h>
#include <BLEUtils.h>
#include <BLEServer.h>

#include "uhs_config.h"


void init_ble();
void sendNotification();
#endif