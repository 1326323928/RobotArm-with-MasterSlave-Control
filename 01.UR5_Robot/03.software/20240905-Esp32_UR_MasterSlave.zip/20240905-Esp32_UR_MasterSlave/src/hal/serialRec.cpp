#include "serialRec.h"

// #define HEADER 0xA1
// #define FOOTER 0xFF
// #define MAX_PACKET_SIZE 255
// uint8_t data[MAX_PACKET_SIZE];
// int bufferIndex = 0;
// bool receiving = false;

HardwareSerial *pRecSerial = nullptr;
const uint8_t length = 32;
uint8_t data[length];

// void processReceivedData(uint8_t *data)
// {
//   // 处理接收到的数据
//   if (data[0] == 0xA1 && data[1] == 0x01)
//   {
//     clamp_run_by_handle_IMU(data + 3);
//     // float yaw = degrees(byteToFloat(data+3+8));
//     // float roll = degrees(byteToFloat(data + 3+12));
//     // float mappitch = map(yaw,-82,85,0,240);

//     // Serial.printf("mapyaw: %f | roll: %f  |  ", mapyaw, roll);
//     // Serial.println();
//   }
//   else if (data[0] == 0xA1 && data[1] == 0x02)
//   {
//     clamp_run_by_handle_AS5600(data + 3);
//     float clampAngle = degrees(byteToFloat(data + 3));
//   }
// }

void processReceivedData(uint8_t *data, uint8_t length)
{
  // 处理接收到的数据
  if (data[0] == 0xA1 && data[1] == 0x02)
  {
    float absPos[7];
    uint8_t j = 0;
    for (uint8_t i = 3; i < length; i += 4)
    {
      absPos[j] = byteToFloat(data+i);
      j++;
    }
    Serial.printf("x: %f | y: %f | z: %f | yaw: %f | pitch: %f | roll: %f | clamp: %f", absPos[0], absPos[1], absPos[2], absPos[3], absPos[4], absPos[5], absPos[6], absPos[7]);
    Serial.println();
    run_by_handle(absPos);
  }
  // else if (data[0] == 0xA1 && data[1] == 0x02)
  // {
  //   clamp_run_by_handle_AS5600(data + 3);
  //   float clampAngle = degrees(byteToFloat(data + 3));
  // }
}


void task_serialRecData(void *pvParameters)
{
  while (1)
  {
    if (isHandle)
    {
      if (pRecSerial->available())
      {
        size_t len = pRecSerial->readBytes(data, length);
        // 检查数据长度
        if (len == length)
        {
          processReceivedData(data,length);
        }
        else
        {
          // 如果数据长度不匹配，可能需要重新接收或者丢弃
          Serial.println("Data length mismatch, discarding data.");
        }
      }
    }
    vTaskDelay(1 / portTICK_PERIOD_MS);
  }
}


// void task_serialRecData(void *pvParameters)
// {
//   while (1)
//   {
//     // if (isHandle)
//     // {
//     while (pRecSerial->available())
//     {
//       uint8_t byte = pRecSerial->read();

//       if (byte == HEADER)
//       {
//         receiving = true;
//       }
//       else if (byte == FOOTER)
//       {
//         processReceivedData(data, bufferIndex);
//         receiving = false;
//         bufferIndex = 0;
//       }
//       if (receiving)
//       {
//         // Serial.printf("%d |", byte);
//         data[bufferIndex] = byte;
//         bufferIndex++;
//       }
//       //}
//     }
//     // Serial.println();
//     vTaskDelay(1 / portTICK_PERIOD_MS);
//   }
// }

void serial_Rec_Init(HardwareSerial *serial)
{
  pRecSerial = serial;
  xTaskCreatePinnedToCore(task_serialRecData, "Serial Rec", 6000, NULL, 2, NULL,1);
}
