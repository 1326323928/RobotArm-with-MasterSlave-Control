#include "uhs_ble.h"
#include "uhs_UR5Ctrl.h"
#include "uhs_kine_3axis.h"

BLECharacteristic *pCharacteristic = NULL;
BLEServer *pServer = NULL;
bool bleConnected = false;

bool get_ble_connect()
{
    return bleConnected;
}

// Server回调函数声明
class bleServerCallbacks : public BLEServerCallbacks
{
    void onConnect(BLEServer *pServer)
    {
        bleConnected = true;
        Serial.println("现在有设备接入~");
    }

    void onDisconnect(BLEServer *pServer)
    {
        bleConnected = false;
        Serial.println("现在有设备断开连接~");
        // 在有设备接入后Advertising广播会被停止，所以要在设备断开连接时重新开启广播
        // 不然的话只有重启ESP32后才能重新搜索到
        pServer->startAdvertising(); // 该行效果同 BLEDevice::startAdvertising();
    }
};

class bleCharacteristicCallbacks : public BLECharacteristicCallbacks
{
    void onRead(BLECharacteristic *pCharacteristic)
    { // 客户端读取事件回调函数
        Serial.println("触发读取事件");
    }

    void onWrite(BLECharacteristic *pCharacteristic)
    { // 客户端写入事件回调函数
        size_t length = pCharacteristic->getLength();
        uint8_t *pdata = pCharacteristic->getData();
        if (length == 16)
        {
            // A1 A2 01 串联机器人  ur5
            if (pdata[0] == 0xA1 && pdata[1] == 0xA2 && pdata[2] == 0x01)
            {
                ur5SingleAxis_ble_callback(pdata + 3);
            }
            // A1 A2 02 运动学功能控制
            if (pdata[0] == 0xA1 && pdata[1] == 0xA2 && pdata[2] == 0x02)
            {
                ur5KineFun_ble_callback(pdata + 3);
            }
        }
    }
    // void onNotify(BLECharacteristic *pCharacteristic)
    // {
    //     Serial.println("Characteristic onNotify");
    // }
};

// void sendNotification()
// {
//     dataPackage sendData = getPos(0);
//     // 发送通知
//     pCharacteristic->setValue(sendData.data, sendData.size);
//     pCharacteristic->notify();
// }

void task_stepperPosReturn(void *pvParameters)
{
    while (1)
    {
        if (bleConnected)
        {
            // sendNotification();
        }
        vTaskDelay(100 / portTICK_PERIOD_MS);
    }
}

void init_ble()
{
    BLEDevice::init(BLE_NAME);                       // 填写自身对外显示的蓝牙设备名称，并初始化蓝牙功能
    BLEDevice::startAdvertising();                   // 开启Advertising广播
    pServer = BLEDevice::createServer();             // 创建服务器
    pServer->setCallbacks(new bleServerCallbacks()); // 绑定回调函数

    BLEService *pService = pServer->createService(SERVICE_UUID); // 创建服务
    pCharacteristic = pService->createCharacteristic(            // 创建特征
        CHARACTERISTIC_UUID,
        BLECharacteristic::PROPERTY_READ |
            BLECharacteristic::PROPERTY_NOTIFY |
            BLECharacteristic::PROPERTY_WRITE |
            BLECharacteristic::PROPERTY_INDICATE);
    // 如果客户端连上设备后没有任何写入的情况下第一次读取到的数据应该是这里设置的值
    pCharacteristic->setCallbacks(new bleCharacteristicCallbacks());
    pCharacteristic->addDescriptor(new BLE2902()); // 添加描述
    pService->start();                             // 启动服务

    BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
    pAdvertising->addServiceUUID(SERVICE_UUID);
    pServer->getAdvertising()->start();
    pAdvertising->setScanResponse(true);
    pAdvertising->setMinPreferred(0x06); // functions that help with iPhone connections issue
    pAdvertising->setMinPreferred(0x12);
    BLEDevice::startAdvertising();
    xTaskCreate(task_stepperPosReturn, "sendPos", 2048, NULL, 1, NULL);
}
