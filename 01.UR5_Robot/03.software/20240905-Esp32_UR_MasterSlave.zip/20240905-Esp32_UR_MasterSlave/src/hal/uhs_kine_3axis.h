#include "uhs_config.h"
#include <math.h>
extern bool isKine;
extern bool isHandle;
void ur5KineFun_ble_callback(uint8_t *data);
void ur5KineInit();
void run_by_handle(float *absPos);







