#include "uhs_config.h"
#include "hal/uhs_posCompute.h"
#include "hal/serial_trans.h"


void setup() 
{
  delay(1000);
  Serial.begin(115200);
  handleInit();
  delay(1000);
  serialTrans_Init();
  delay(100);
}


void loop() 
{

}