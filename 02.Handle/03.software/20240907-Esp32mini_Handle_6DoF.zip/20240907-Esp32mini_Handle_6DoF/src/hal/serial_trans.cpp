#include "serial_trans.h"
#define TRANS_RX_PIN 10
#define TRANS_TX_PIN 9

HardwareSerial TransSerial(1);

void task_serialSendAS5600Data(void *pvParameters)
{
    while (1)
    {
        dataPackage handleData = getHandlePos();
        TransSerial.write(handleData.data, handleData.size);
        // delay(3);
        // dataPackage handleRawData = getRawPos();
        // Serial.write(handleRawData.data, handleRawData.size);
        vTaskDelay(5 / portTICK_PERIOD_MS);
    }
}

void serialTrans_Init()
{
    TransSerial.begin(115200, SERIAL_8N1, TRANS_RX_PIN, TRANS_TX_PIN);
    Serial.println("TransSerial Starting ~ ~ ~");
    while (!TransSerial)
    {
        Serial.println("TransSerial Starting Failed!");
    }
    Serial.println("TransSerial Started!!!");
    xTaskCreate(task_serialSendAS5600Data, "Serial trans AS5600", 4096, NULL, 1, NULL);
}
