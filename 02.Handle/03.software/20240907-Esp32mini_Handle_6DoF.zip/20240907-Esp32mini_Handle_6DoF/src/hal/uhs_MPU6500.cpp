#include "uhs_MPU6500.h"
#define _2PI 6.28318530718f

float Sensor_MPU6500::getPitch()
{
    return angle.x * (_2PI / 360);
}

float Sensor_MPU6500::getRoll()
{
    return angle.y * (_2PI / 360);
}

float Sensor_MPU6500::getDeviation()
{
    return angle.z * (_2PI / 360);
}

float Sensor_MPU6500::getGX()
{
    return gValue.x;
}

float Sensor_MPU6500::getGY()
{
    return gValue.y;
}

float Sensor_MPU6500::getGZ()
{
    return gValue.z;
}

void Sensor_MPU6500::Sensor_update()
{
    gValue = MPU6500.getGValues();
    gyr = MPU6500.getGyrValues();
    angle = MPU6500.getAngles();
    temp = MPU6500.getTemperature();
    resultantG = MPU6500.getResultantG(gValue);
}

void Sensor_MPU6500::Sensor_init()
{
    while (!MPU6500.init())
    {
        Serial.println("MPU6500 does not respond");
        delay(500);
    }
    Serial.println("MPU6500 is connected");
    MPU6500.enableGyrDLPF();
    MPU6500.setGyrDLPF(MPU6500_DLPF_6);
    MPU6500.setSampleRateDivider(5);
    MPU6500.setGyrRange(MPU6500_GYRO_RANGE_250);
    MPU6500.setAccRange(MPU6500_ACC_RANGE_2G);
    MPU6500.enableAccDLPF(true);
    MPU6500.setAccDLPF(MPU6500_DLPF_6);
    delay(100);
}
