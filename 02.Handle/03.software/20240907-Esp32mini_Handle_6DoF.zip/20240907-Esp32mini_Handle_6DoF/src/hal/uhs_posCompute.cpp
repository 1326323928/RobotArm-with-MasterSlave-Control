#include "uhs_posCompute.h"
#include <SimpleKalmanFilter.h>
#include <ArduinoEigenDense.h> // 使用Eigen库进行矩阵运算
using namespace Eigen;

#define SDA 7
#define SCL 8

#define PWM_PIN1 3
#define PWM_PIN2 4
#define PWM_PIN3 5
#define PWM_PIN4 1

#define BTN_PIN1 6
#define BTN_PIN2 2

#define TCA9548A_ADDR 0x70
// 通道 0：0x01（二进制：00000001）
// 通道 1：0x02（二进制：00000010）
// 通道 2：0x04（二进制：00000100）
// 通道 3：0x08（二进制：00001000）
// 通道 4：0x10（二进制：00010000）
// 通道 5：0x20（二进制：00100000）
// 通道 6：0x40（二进制：01000000）
// 通道 7：0x80（二进制：10000000）
// I2C 地址选择寄存器
#define TCA9548A_AXIS1 0x01
#define TCA9548A_AXIS2 0x02
#define TCA9548A_AXIS3 0x04
#define TCA9548A_AXIS4 0x20
#define TCA9548A_AXIS_CLAMP 0x80
#define TCA9548A_CHANNEL_ALL 0xFF // 关闭所有通道

TwoWire Sens_I2C = TwoWire(0);
Sensor_MPU6500 Sens_MPU5600(&Sens_I2C);
Sensor_AS5600 Sens_AS5600_1(&Sens_I2C);
Sensor_AS5600 Sens_AS5600_2(&Sens_I2C);
Sensor_AS5600 Sens_AS5600_3(&Sens_I2C);
Sensor_AS5600 Sens_AS5600_4(&Sens_I2C);
Sensor_AS5600 Sens_AS5600_Clamp(&Sens_I2C);

// SimpleKalmanFilter kalmanX(0.1, 0.01, 0.01); // Kalman Filter for X axis
// SimpleKalmanFilter kalmanY(0.1, 0.01, 0.01); // Kalman Filter for Y axis

float d[6] = {82.5, 150, 150, 0, 0, 86.5};
float absPos[7] = {0, 0, 0, 0, 0, 0, 0}; // 1-6为x,y,z,alpha,theta,beta,7为夹爪角度
float axisDeg[5] = {0, 0, 0, 0, 0};
float alpha_p = 0.1;                         // 控制滤波器的实时性 position
float alpha_e = 0.1;                         // 控制滤波器的实时性 euler
float filt_1_Pos[7] = {0, 0, 0, 0, 0, 0, 0}; // 第一次滤波的结果
float filt_2_Pos[7] = {0, 0, 0, 0, 0, 0, 0}; // 第二次滤波的结果

void selectTCA9548AChannel(uint8_t channel)
{
    Sens_I2C.beginTransmission(TCA9548A_ADDR);
    Sens_I2C.write(channel); // 选择通道
    Sens_I2C.endTransmission();
}

///////////////////////////////////////////    解算姿态     /////////////////////////////////////////////
uint8_t byArr_RawPos[32] = {0xA1, 0x01, 28,
                            00, 00, 00, 00,
                            00, 00, 00, 00,
                            00, 00, 00, 00,
                            00, 00, 00, 00,
                            00, 00, 00, 00,
                            00, 00, 00, 00,
                            00, 00, 00, 00,
                            0xFF};

uint8_t byArr_HandlePos[32] = {0xA1, 0x02, 28,
                               00, 00, 00, 00,
                               00, 00, 00, 00,
                               00, 00, 00, 00,
                               00, 00, 00, 00,
                               00, 00, 00, 00,
                               00, 00, 00, 00,
                               00, 00, 00, 00,
                               0xFF};

dataPackage getHandlePos()
{
    Sens_MPU5600.Sensor_update();

    // 1轴
    selectTCA9548AChannel(TCA9548A_AXIS1);
    delayMicroseconds(200);
    Sens_AS5600_1.Sensor_update();
    axisDeg[0] = -(degrees(Sens_AS5600_1.getMechanicalAngle()) - 322);
    // 2轴
    selectTCA9548AChannel(TCA9548A_AXIS2);
    delayMicroseconds(200);
    Sens_AS5600_2.Sensor_update();
    axisDeg[1] = -(degrees(Sens_AS5600_2.getMechanicalAngle()) - 200);
    // 3轴
    selectTCA9548AChannel(TCA9548A_AXIS3);
    delayMicroseconds(200);
    Sens_AS5600_3.Sensor_update();
    axisDeg[2] = degrees(Sens_AS5600_3.getMechanicalAngle()) - 236.5;
    // 4轴 偏摆
    selectTCA9548AChannel(TCA9548A_AXIS4);
    delayMicroseconds(200);
    Sens_AS5600_4.Sensor_update();
    axisDeg[3] = degrees(Sens_AS5600_4.getMechanicalAngle()) - 275+192.5;
    // 夹爪轴
    selectTCA9548AChannel(TCA9548A_AXIS_CLAMP);
    delayMicroseconds(200);
    Sens_AS5600_Clamp.Sensor_update();
    axisDeg[4] = degrees(Sens_AS5600_Clamp.getMechanicalAngle()) - 270;

    // float temp = d[1] * (-1 * sin(radians(axisDeg[1]))) + d[2] * cos(radians(axisDeg[2]));
    // absPos[0] = temp * -1 * sin(radians(axisDeg[0]));
    // absPos[1] = temp * (cos(radians(axisDeg[0])));
    // absPos[2] = d[1] * cos(radians(axisDeg[1])) + d[2] * sin(radians(axisDeg[2]));

    absPos[3] = axisDeg[3]-axisDeg[0];                        // yaw
    absPos[4] = -degrees(Sens_MPU5600.getRoll());  // pitch
    absPos[5] = -degrees(Sens_MPU5600.getPitch()); // roll
    absPos[6] = axisDeg[4];                        // clamp

    float temp = d[1] * (-1 * sin(radians(axisDeg[1]))) + d[2] * cos(radians(axisDeg[2]));
    absPos[0] = temp * -1 * sin(radians(axisDeg[0])) + d[5] * -1 * sin(radians(axisDeg[0])) * cos(radians(absPos[4]));
    absPos[1] = temp * (cos(radians(axisDeg[0]))) + d[5] * (cos(radians(axisDeg[0]))) * cos(radians(absPos[4]));
    absPos[2] = d[1] * cos(radians(axisDeg[1])) + d[2] * sin(radians(axisDeg[2])) + d[5] * (cos(radians(axisDeg[0]))) * sin(radians(absPos[4]));

    // 姿态换方向，比例映射
    absPos[0] = -1 * absPos[0];
    absPos[1] = 150 + 86.5 - absPos[1];
    absPos[2] = absPos[2]-250;

    // 第一次滤波
    filt_1_Pos[0] = alpha_p * absPos[0] + (1 - alpha_p) * filt_1_Pos[0];
    filt_1_Pos[1] = alpha_p * absPos[1] + (1 - alpha_p) * filt_1_Pos[1];
    filt_1_Pos[2] = alpha_p * absPos[2] + (1 - alpha_p) * filt_1_Pos[2];

    filt_1_Pos[3] = alpha_e * absPos[3] + (1 - alpha_e) * filt_1_Pos[3];
    filt_1_Pos[4] = alpha_e * absPos[4] + (1 - alpha_e) * filt_1_Pos[4];
    filt_1_Pos[5] = alpha_e * absPos[5] + (1 - alpha_e) * filt_1_Pos[5];
    filt_1_Pos[6] = alpha_e * absPos[6] + (1 - alpha_e) * filt_1_Pos[6];

    // 第二次滤波
    filt_2_Pos[0] = alpha_p * filt_1_Pos[0] + (1 - alpha_p) * filt_2_Pos[0];
    filt_2_Pos[1] = alpha_p * filt_1_Pos[1] + (1 - alpha_p) * filt_2_Pos[1];
    filt_2_Pos[2] = alpha_p * filt_1_Pos[2] + (1 - alpha_p) * filt_2_Pos[2];

    filt_2_Pos[3] = alpha_e * filt_1_Pos[3] + (1 - alpha_e) * filt_2_Pos[3];
    filt_2_Pos[4] = alpha_e * filt_1_Pos[4] + (1 - alpha_e) * filt_2_Pos[4];
    filt_2_Pos[5] = alpha_e * filt_1_Pos[5] + (1 - alpha_e) * filt_2_Pos[5];
    filt_2_Pos[6] = alpha_e * filt_1_Pos[6] + (1 - alpha_e) * filt_2_Pos[6];

    // 将浮点数组转为byte数组
    size_t floatArraySize = sizeof(filt_2_Pos) / sizeof(float);
    floatArray2ByteArray(filt_2_Pos, byArr_HandlePos, 3, floatArraySize);
    dataPackage HandlePosData;
    HandlePosData.data = byArr_HandlePos;
    HandlePosData.size = sizeof(byArr_HandlePos);
    // Serial.printf("ang1: %f | ang2: %f | ang3: %f | ang4: %f | clamp: %f", axisDeg[0], axisDeg[1], axisDeg[2], axisDeg[3], axisDeg[4]);
    Serial.printf("x: %f | y: %f | z: %f | yaw: %f | pitch: %f | roll: %f | clamp: %f ", absPos[0], absPos[1], absPos[2], absPos[3], absPos[4], absPos[5], absPos[6]);
    // Serial.printf("x: %f | y: %f | z: %f | yaw: %f | pitch: %f | roll: %f | clamp: %f ", filt_2_Pos[0], filt_2_Pos[1], filt_2_Pos[2], filt_2_Pos[3], filt_2_Pos[4], filt_2_Pos[5], absPos[6]);
    Serial.println();

    return HandlePosData;
}

dataPackage getRawPos()
{
    // 将浮点数组转为byte数组
    size_t floatArraySize = sizeof(absPos) / sizeof(float);
    floatArray2ByteArray(absPos, byArr_RawPos, 3, floatArraySize);
    dataPackage HandleRawPosData;
    HandleRawPosData.data = byArr_RawPos;
    HandleRawPosData.size = sizeof(byArr_RawPos);
    return HandleRawPosData;
}

void handleInit()
{
    // pinMode(PWM_PIN1, INPUT);
    // pinMode(PWM_PIN2, INPUT);
    // pinMode(PWM_PIN3, INPUT_PULLUP);
    // 初始化i2c总线

    Sens_I2C.begin(SDA, SCL, 400000UL);
    // 初始化MPU6500
    Sens_MPU5600.Sensor_init();
    Serial.println("IMU加载完毕！");
    delay(1000);
    Sens_AS5600_1.Sensor_init();
    Serial.println("AS5600加载完毕！");
    delay(100);
}
